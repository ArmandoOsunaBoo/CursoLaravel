<h2>Bienvenido {{ $user->name  }}</h2>
