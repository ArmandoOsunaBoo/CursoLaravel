<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
  </head>
  <body>
    @yield('content')
  </body>
</html>
