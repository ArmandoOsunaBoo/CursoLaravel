<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>