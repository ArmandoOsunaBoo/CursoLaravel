Error 500
<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/errors/500.blade.php ENDPATH**/ ?>