<h2>Bienvenido <?php echo e($user->name); ?></h2>
<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/mails/welcome.blade.php ENDPATH**/ ?>