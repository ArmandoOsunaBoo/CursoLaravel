  

 <?php $__env->startSection('title',"View: Vista"); ?>

 <?php $__env->startSection('content'); ?>
   <p>Hola</p>
   <img src="<?php echo e(asset('img/gatito.jpg')); ?>" alt="">
 <?php $__env->stopSection(); ?>


 <?php $__env->startSection('sidebar'); ?>
 ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
   <p>Hola desde vista</p>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/vista.blade.php ENDPATH**/ ?>