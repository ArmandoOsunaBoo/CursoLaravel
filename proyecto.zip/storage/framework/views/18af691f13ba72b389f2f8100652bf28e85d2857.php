Error 404
<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/errors/404.blade.php ENDPATH**/ ?>