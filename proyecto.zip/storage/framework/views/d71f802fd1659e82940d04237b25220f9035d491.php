<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>
  
    <?php echo $__env->make('_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
      <h1><?php echo app('translator')->get('archivo.titular'); ?></h1>
      <?php $__env->startSection('sidebar'); ?>
      <h2>Hola desde welcome</h2>
      <?php echo $__env->yieldSection(); ?>
  </body>
</html>
<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/welcome.blade.php ENDPATH**/ ?>