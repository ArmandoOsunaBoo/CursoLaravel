


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="alert alert-danger" role="alert">
    <?php echo e($error); ?>

  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<form  method="post" action=" <?php echo e(route('post.update',['post'=>$post])); ?>  ">
  <input type="hidden" name="_method" value="PUT">
  <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
  <?php echo csrf_field(); ?>
        <div class="row justify-content-center">
          <div class="col-md-8">
            <div class="form-group">
              <label for="title">Titulo</label>
              <input type="text" class="form-control" name="title" placeholder="" value="<?php echo e($post->title); ?>" >
            </div>
            <div class="form-group">
              <label for="content">Contenido</label>
            <textarea class="form-control" aria-label="With textarea" style="margin-top: 0px; margin-bottom: 0px; height: 134px;" name="content"><?php echo e($post->content); ?></textarea>
            </div>
             <div class="form-group">
             <hr class="mb-4">
             <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
           </div>
          </div>

      </form>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/post/edit.blade.php ENDPATH**/ ?>