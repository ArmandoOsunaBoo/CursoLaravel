<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
  </body>
</html>
<?php /**PATH C:\Users\ArmandoPCGB\Documents\Mi proyecto\proyecto\resources\views/layouts/_main.blade.php ENDPATH**/ ?>